#!/usr/bin/env bash
# One-shot installer for the Listen Together server on an Oracle Cloud
# (or any Ubuntu 22.04/24.04) VM. Safe to re-run: it rebuilds and restarts.
#
#   sudo DOMAIN=jam.bitchord.kushagrasingh.in bash deploy/setup.sh
#
# First run on a fresh VM also takes DEPLOY_PUBKEY (the public half of the
# GitHub Actions deploy key) to create the restricted `deploy` user.
#
# Run it from the backend/ directory of a checkout on the VM. The DNS A record
# for $DOMAIN must already point at this VM, or Caddy cannot get a certificate.
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

DOMAIN="${DOMAIN:?set DOMAIN, e.g. DOMAIN=jam.bitchord.kushagrasingh.in}"
GO_VERSION="${GO_VERSION:-1.27.0}"
BACKEND_DIR="$(cd "$(dirname "$0")/.." && pwd)"

case "$(uname -m)" in
  aarch64) GOARCH=arm64 ;;   # Ampere A1 shape
  x86_64)  GOARCH=amd64 ;;   # E2.1.Micro shape
  *) echo "unsupported arch $(uname -m)"; exit 1 ;;
esac

echo "== packages"
if ! dpkg -s curl git gnupg iptables-persistent >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y curl git debian-keyring debian-archive-keyring apt-transport-https gnupg iptables-persistent
fi

echo "== Go $GO_VERSION"
if ! /usr/local/go/bin/go version 2>/dev/null | grep -q "go$GO_VERSION"; then
  curl -fsSL "https://go.dev/dl/go$GO_VERSION.linux-$GOARCH.tar.gz" -o /tmp/go.tgz
  rm -rf /usr/local/go && tar -C /usr/local -xzf /tmp/go.tgz && rm /tmp/go.tgz
fi

echo "== build"
id bitchord >/dev/null 2>&1 || useradd --system --no-create-home --shell /usr/sbin/nologin bitchord
install -d -o bitchord -g bitchord /opt/bitchord-jam
(cd "$BACKEND_DIR" && /usr/local/go/bin/go build -o /opt/bitchord-jam/server .)
chown bitchord:bitchord /opt/bitchord-jam/server

echo "== service"
install -m 644 "$BACKEND_DIR/deploy/bitchord-jam.service" /etc/systemd/system/bitchord-jam.service
systemctl daemon-reload
systemctl enable bitchord-jam
systemctl restart bitchord-jam
# The CPU keepalive burner is retired; clean it off VMs that still have it.
if [ -f /etc/systemd/system/bitchord-keepalive.service ]; then
  systemctl disable --now bitchord-keepalive || true
  rm -f /etc/systemd/system/bitchord-keepalive.service
  systemctl daemon-reload
fi

echo "== caddy (HTTPS + WebSocket proxy)"
if ! command -v caddy >/dev/null; then
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y && apt-get install -y caddy
fi
sed "s/{\$DOMAIN}/$DOMAIN/" "$BACKEND_DIR/deploy/Caddyfile" > /tmp/Caddyfile
if ! cmp -s /tmp/Caddyfile /etc/caddy/Caddyfile; then
  mv /tmp/Caddyfile /etc/caddy/Caddyfile
  systemctl reload caddy || systemctl restart caddy
fi
# Hard memory cap so a runaway Caddy is killed and restarted alone rather than the
# whole 1 GB VM thrashing swap. No soft GOMEMLIMIT: a limit below the working set
# made the Go GC run flat out on a CPU the hypervisor was already starving.
install -d /etc/systemd/system/caddy.service.d
cat > /etc/systemd/system/caddy.service.d/memory.conf <<'UNIT'
[Service]
MemoryMax=750M
Restart=always
RestartSec=2
UNIT
systemctl daemon-reload

echo "== deploy hook"
echo "$DOMAIN" > /etc/bitchord-domain
install -m 755 "$BACKEND_DIR/deploy/bitchord-deploy.sh" /usr/local/sbin/bitchord-deploy

if [ -n "${DEPLOY_PUBKEY:-}" ]; then
  echo "== deploy user"
  # The GitHub Actions key may only run the deploy hook (forced command).
  id deploy >/dev/null 2>&1 || useradd --create-home --shell /bin/bash deploy
  install -d -m 700 -o deploy -g deploy /home/deploy/.ssh
  printf 'command="sudo /usr/local/sbin/bitchord-deploy",no-port-forwarding,no-X11-forwarding,no-agent-forwarding,no-pty %s\n' "$DEPLOY_PUBKEY" > /home/deploy/.ssh/authorized_keys
  chown deploy:deploy /home/deploy/.ssh/authorized_keys && chmod 600 /home/deploy/.ssh/authorized_keys
  echo 'deploy ALL=(root) NOPASSWD: /usr/local/sbin/bitchord-deploy' > /etc/sudoers.d/bitchord-deploy
  chmod 440 /etc/sudoers.d/bitchord-deploy && visudo -cf /etc/sudoers.d/bitchord-deploy
fi

echo "== kernel network limits"
# The micro VM's default conntrack table is tiny (7680) and keeps an idle
# established TCP flow for five days, which is how a crowd of phones that
# vanish without a FIN would fill it. Give it room and a one-hour memory.
cat > /etc/sysctl.d/90-bitchord.conf <<'SYSCTL'
net.netfilter.nf_conntrack_max = 65536
net.netfilter.nf_conntrack_tcp_timeout_established = 3600
SYSCTL
# Load the module at boot, or systemd-sysctl runs before it exists and the limit is lost.
echo nf_conntrack > /etc/modules-load.d/nf_conntrack.conf
sysctl --system >/dev/null 2>&1 || true

echo "== swap"
# 1 GB of RAM and no swap meant a connection spike could get Caddy OOM-killed.
if ! swapon --show --noheadings | grep -q .; then
  fallocate -l 2G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi
echo 'vm.swappiness = 1' > /etc/sysctl.d/91-bitchord-swap.conf
sysctl -q -p /etc/sysctl.d/91-bitchord-swap.conf || true

echo "== tcp buffers + health watchdog"
# Smaller default TCP buffers so thousands of idle sockets cost less kernel memory.
cat > /etc/sysctl.d/92-bitchord-tcp.conf <<'SYSCTL'
net.ipv4.tcp_rmem = 4096 16384 262144
net.ipv4.tcp_wmem = 4096 16384 262144
SYSCTL
sysctl -q -p /etc/sysctl.d/92-bitchord-tcp.conf || true
cat > /usr/local/sbin/bitchord-watchdog <<'WATCHDOG'
#!/usr/bin/env bash
# Restarts Caddy when the public health check has failed twice in a row. The 1 GB
# VM can get wedged under a connection surge; this heals it within ~2 minutes
# instead of waiting for a human. At most one restart per 5 minutes.
DOMAIN="$(cat /etc/bitchord-domain)"
F=/run/bitchord-watchdog.fails; L=/run/bitchord-watchdog.last
if curl -sk -m6 -o /dev/null -f --resolve "$DOMAIN:443:127.0.0.1" "https://$DOMAIN/healthz"; then echo 0 > $F; exit 0; fi
n=$(( $(cat $F 2>/dev/null || echo 0) + 1 )); echo $n > $F
[ "$n" -lt 2 ] && exit 0
now=$(date +%s); last=$(cat $L 2>/dev/null || echo 0)
[ $((now - last)) -lt 300 ] && exit 0
echo $now > $L; echo 0 > $F
logger -t bitchord-watchdog "health check failed twice; restarting caddy"
systemctl restart caddy
WATCHDOG
chmod 755 /usr/local/sbin/bitchord-watchdog
cat > /etc/systemd/system/bitchord-watchdog.service <<'UNIT'
[Unit]
Description=Restart Caddy if the health check keeps failing
[Service]
Type=oneshot
ExecStart=/usr/local/sbin/bitchord-watchdog
UNIT
cat > /etc/systemd/system/bitchord-watchdog.timer <<'UNIT'
[Unit]
Description=Run the BitChord health watchdog every minute
[Timer]
OnBootSec=3min
OnUnitActiveSec=60s
AccuracySec=5s
[Install]
WantedBy=timers.target
UNIT
systemctl daemon-reload
systemctl enable --now bitchord-watchdog.timer >/dev/null 2>&1 || true

echo "== firewall"
# Oracle's Ubuntu images ship an iptables REJECT rule that blocks everything
# but SSH, independent of the VCN security list. Open 80/443 above it.
for port in 80 443; do
  while iptables -D INPUT -p tcp --dport "$port" -m state --state NEW -j ACCEPT 2>/dev/null; do :; done
  reject="$(iptables -L INPUT --line-numbers -n | awk '$2 == "REJECT" { print $1; exit }')"
  iptables -I INPUT "${reject:-1}" -p tcp --dport "$port" -m state --state NEW -j ACCEPT
done
netfilter-persistent save

echo "== check"
sleep 2
curl -fsS http://127.0.0.1:8000/healthz && echo
echo "Done. Once DNS resolves, https://$DOMAIN/healthz should answer."
