# Build the BitChord APK

BitChord source (GPLv3) from https://github.com/kushagrasinghx/BitChord, commit 04a4a83.

## Option A: Android Studio (easiest)
1. Install Android Studio (latest) with JDK 17+ and the Android SDK Platform 37.
2. File > Open > select the `bitchord` folder. Let Gradle sync finish (first sync is slow).
3. Build > Generate App Bundles or APKs > Generate APKs, or run the `prod` release variant.
4. The APK appears under `app/build/outputs/apk/`.

## Option B: command line
1. Install JDK 17+ and the Android SDK (platform 37, build-tools).
2. Create `local.properties` in the project root:
   `sdk.dir=/path/to/Android/Sdk`
   (without it, Gradle skips the Android module and builds desktop targets only)
3. Run:
   `./gradlew assembleProdRelease`   (Windows: `gradlew.bat assembleProdRelease`)

## Signing
A release APK must be signed to install.
1. Copy `keystore.properties.example` to `keystore.properties`.
2. Create a keystore: `keytool -genkey -v -keystore bitchord-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias bitchord`
3. Fill in the passwords in `keystore.properties`. Keep the .jks and passwords safe; losing them means future updates can't install over this one.

## Install
Copy the APK to your phone, enable "Install unknown apps" for your file manager, and open it.

## Shortcut
The upstream project publishes signed APKs at https://github.com/kushagrasinghx/BitChord/releases

## Changes in this version
- Privacy: removed the "apps open right now" presence ping, disabled self-update from upstream GitHub, removed the REQUEST_INSTALL_PACKAGES permission.
- Home (Play) screen: new "Recommended playlists" section. It contains Recents (list view, or a Spotify-style two-column tile grid) followed by the feed's playlist shelves. Code: sharedUi/.../ui/screens/HomeScreen.kt.
- These UI changes were not compiled in the authoring environment (no Android SDK access). If Gradle reports an error, it will be in HomeScreen.kt.
